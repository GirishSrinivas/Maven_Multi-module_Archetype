package com.oriental.${cometServiceNameLowerCase}.client.invoker;

import com.oriental.${cometServiceNameLowerCase}.business.exception.${cometServiceNameCapitalized}ServiceException;

public interface ${cometServiceNameCapitalized}ServiceInvoker
{
	void setEndpointurl(String endpoint) throws ${cometServiceNameCapitalized}ServiceException;
	void setTimeout(Integer timeout);
}