package com.oriental.${cometServiceNameLowerCase}.test;
import org.junit.Test;

public class ${cometServiceNameCapitalized}ClientTest
{
	@Test
	public void ${cometServiceNameLowerCase}Test()
	{
		
	}
}
