package com.oriental.${cometServiceNameLowerCase}.client.invoker.impl;

import java.io.IOException;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sun.jersey.api.client.ClientResponse;

import com.oriental.${cometServiceNameLowerCase}.business.exception.${cometServiceNameCapitalized}ServiceException;
import com.oriental.${cometServiceNameLowerCase}.client.invoker.${cometServiceNameCapitalized}ServiceInvoker;

public class ${cometServiceNameCapitalized}ServiceInvokerImpl implements ${cometServiceNameCapitalized}ServiceInvoker
{
	private static Integer MAX_CONNECTION_TIME_OUT = 30000;
	private String endpointUrl;
	private static Logger logger = LoggerFactory.getLogger(${cometServiceNameCapitalized}ServiceInvokerImpl.class);
	private ObjectMapper objectMapper = new ObjectMapper();

	public ${cometServiceNameCapitalized}ServiceInvokerImpl() {
		super();
	}
	
	@Override
	public void setTimeout(Integer timeout) {
		MAX_CONNECTION_TIME_OUT = timeout;
	}
	
	@Override
	public void setEndpointurl(String endpointurl) {
		this.endpointUrl = endpointurl;
		logger.info("EndPoint url[{}]" + endpointurl);
	}

	private String getEndpointurl() {
		return endpointUrl;
	}
	
	private String getJsonReply(ClientResponse response) {
		String reply = response.getEntity(String.class);
		int start = StringUtils.indexOf(reply, "entity");
		int endIndex = StringUtils.indexOf(reply, "entityType");
		String jsonReply = StringUtils.substring(reply, start + 8, endIndex - 2);
		return jsonReply;
	}
	
	
}

