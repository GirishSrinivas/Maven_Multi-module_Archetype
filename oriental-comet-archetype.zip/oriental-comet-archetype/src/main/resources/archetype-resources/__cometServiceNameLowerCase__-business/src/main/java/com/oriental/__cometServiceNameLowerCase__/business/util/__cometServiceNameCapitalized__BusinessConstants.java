package com.oriental.${cometServiceNameLowerCase}.business.util;

public class ${cometServiceNameCapitalized}BusinessConstants
{
	public static final String REST_CONTEXT = "/rest";
}