package com.oriental.${cometServiceNameLowerCase}.business.exception;

public class ${cometServiceNameCapitalized}ServiceException extends RuntimeException
{
	private static final long serialVersionUID = 1L;
	
	public ${cometServiceNameCapitalized}ServiceException() {
	}

	public ${cometServiceNameCapitalized}ServiceException(String message) {
		super(message);
	}

	public ${cometServiceNameCapitalized}ServiceException(Throwable cause) {
		super(cause);
	}

	public ${cometServiceNameCapitalized}ServiceException(String message, Throwable cause) {
		super(message, cause);
	}
	
	@Override 
	public String toString() { 
		return super.toString(); 
	}
}