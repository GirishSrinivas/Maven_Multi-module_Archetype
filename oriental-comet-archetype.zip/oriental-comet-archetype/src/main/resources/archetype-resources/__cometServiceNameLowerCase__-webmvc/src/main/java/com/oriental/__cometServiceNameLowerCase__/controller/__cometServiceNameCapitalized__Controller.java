package com.oriental.${cometServiceNameLowerCase}.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;
import javax.validation.Validator;
import com.oriental.edi.common.exceptions.ConfigurationException;
import com.oriental.edi.common.utilities.PropertiesInterface;
import com.oriental.${cometServiceNameLowerCase}.service.${cometServiceNameCapitalized}ServiceFactory;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.validation.Errors;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
public class ${cometServiceNameCapitalized}Controller
{
	private final Logger logger = LoggerFactory.getLogger(this.getClass());
	
	private static String localPropertiesURL = "http://localhost:7001/property-service-webmvc/rest/";
	public static String propertiesURL = "";
	public static String propertiesParams = "?system=COMET&environment=DGTLEXP";
	public static Map<String,String> properties;
	
	@Autowired
	private Validator validator;	
	
	@Autowired
	private ${cometServiceNameCapitalized}ServiceFactory service;
	
	
	/**  
	 * After initializing, instantiate HashMap and attempt to 
	 * contact properties server to retrieve context
	 */
	@PostConstruct
	public void retrieveProperties() 
	{
		logger.debug("Post Construct"); 
		logger.debug(" propertiesURL::" +  System.getProperty("propertiesURL"));
		
		synchronized (propertiesURL) 
		{
			propertiesURL = System.getProperty("propertiesURL") + propertiesParams; 
		}
		
		logger.debug("Properties service URL: " + propertiesURL);	 
		properties = new HashMap<String, String>();	 
		loadProperties(PropertiesInterface.contactPropertiesService(propertiesURL));		
	}
	
	
	/** 
	 * iterate through list of properties and 
	 * load into HashMap
	 * 
	 * @param WarehouseCodes codes
	 */
	private void loadProperties(HashMap<String, String> retrievedProperties)
	{		
		synchronized (properties) 
		{
			properties = retrievedProperties;
		}
	}
	
	
	/** 
	 * 
	 * Allow outside REST call to force a refresh
	 * 
	 * @return String, list of properties
	 */
	@ResponseBody
	@RequestMapping(value = "/", method = RequestMethod.GET, params = {"refreshProperties=true"})
	public String refreshProperties() 
	{
		
		loadProperties(PropertiesInterface.contactPropertiesService(propertiesURL));
		
		logger.debug(properties.toString());		

		checkProperties();
		
		return properties.toString();
	}	
	
	
	/** 
	 * Check that properties were retrieved
	 * If not try again and throw config
	 * error if unable to load from service
	 */
	public void checkProperties()
	{
		if (properties.isEmpty()) 
		{
			refreshProperties();
		
			if (properties.isEmpty())
				throw new ConfigurationException("Unable to load properties");
		}	
	}  	
	
	
	
}