package com.oriental.${cometServiceNameLowerCase}.utils;



/**
 * This class contains all the URL mappings for the project...
 * @author gsrinivas
 *
 */

public class ${cometServiceNameCapitalized}URLMappingConstants
{
	String TEST = "/test";
}