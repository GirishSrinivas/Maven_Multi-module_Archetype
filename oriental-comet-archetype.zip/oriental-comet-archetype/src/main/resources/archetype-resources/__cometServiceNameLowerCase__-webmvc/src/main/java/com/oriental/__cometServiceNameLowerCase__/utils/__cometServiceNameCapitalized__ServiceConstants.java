package com.oriental.${cometServiceNameLowerCase}.utils;



/**
 * This class contains all the constants used in the project...
 * @author gsrinivas
 *
 */

public class ${cometServiceNameCapitalized}ServiceConstants
{
	public static final String TEST_STRING = "Testing the prod..."; 
}