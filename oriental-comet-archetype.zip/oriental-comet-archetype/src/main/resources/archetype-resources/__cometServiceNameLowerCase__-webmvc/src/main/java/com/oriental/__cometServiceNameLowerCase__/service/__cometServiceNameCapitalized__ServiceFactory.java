package com.oriental.${cometServiceNameLowerCase}.service;


public interface ${cometServiceNameCapitalized}ServiceFactory
{
	public void getName();
}
