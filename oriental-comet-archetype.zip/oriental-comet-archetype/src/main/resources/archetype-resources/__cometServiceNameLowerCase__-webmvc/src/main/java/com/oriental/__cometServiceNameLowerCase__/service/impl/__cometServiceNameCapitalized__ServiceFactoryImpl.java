package com.oriental.${cometServiceNameLowerCase}.service.impl;

import com.oriental.${cometServiceNameLowerCase}.service.${cometServiceNameCapitalized}ServiceFactory;

public class ${cometServiceNameCapitalized}ServiceFactoryImpl implements ${cometServiceNameCapitalized}ServiceFactory
{
	@Override
	public void getName()
	{
		System.out.println("In ServiceFactoryImpl()");
	}
}