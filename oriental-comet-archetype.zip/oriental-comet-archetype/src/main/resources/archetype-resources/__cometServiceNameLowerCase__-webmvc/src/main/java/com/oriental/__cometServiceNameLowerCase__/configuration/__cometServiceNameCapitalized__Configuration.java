package com.oriental.${cometServiceNameLowerCase}.configuration;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.context.support.ReloadableResourceBundleMessageSource;
import org.springframework.core.LocalVariableTableParameterNameDiscoverer;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.validation.beanvalidation.LocalValidatorFactoryBean;
import org.springframework.validation.beanvalidation.MethodValidationPostProcessor;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.oriental.comet.db2.config.EnterpriseDbConfig;

/**
 * 
 * @author gsrinivas
 *
 */

@Configuration
@EnableWebMvc
@Import({EnterpriseDbConfig.class, SwaggerConfiguration.class})
@ComponentScan(basePackages = {"com.oriental.${cometServiceNameLowerCase}","com.oriental.comet.db2.dao"})
public class ${cometServiceNameCapitalized}Configuration extends WebMvcConfigurerAdapter
{
	@Override
	public void addResourceHandlers(ResourceHandlerRegistry registry)
	{
		registry.addResourceHandler("swagger-ui.html").addResourceLocations("classpath:/META-INF/resources/");

		registry.addResourceHandler("/webjars/**").addResourceLocations("classpath:/META-INF/resources/webjars/");
	}
	
	 @Bean
	 public MappingJackson2HttpMessageConverter mappingJackson2HttpMessageConverter() 
	 {
	        MappingJackson2HttpMessageConverter converter = new MappingJackson2HttpMessageConverter();
	        converter.setObjectMapper(new ObjectMapper().configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false));
	        return converter;
	 }

	 @Bean
	 public MessageSource messageSource()
	 {		 
		 ReloadableResourceBundleMessageSource messageSource = new ReloadableResourceBundleMessageSource();
		 messageSource.setBasename("validation");
		 messageSource.setCacheSeconds(1);

		 return messageSource;		 
	 }
	 
	 @Bean(name="validator")
	 public LocalValidatorFactoryBean localValidatorFactoryBean()
	 {
		 LocalValidatorFactoryBean bean = new LocalValidatorFactoryBean();
		 bean.setValidationMessageSource(messageSource());
		 bean.setParameterNameDiscoverer(new LocalVariableTableParameterNameDiscoverer());
		 
		 return bean;
	 }
	 
	 @Bean
	 @Autowired
	 MethodValidationPostProcessor getValidationPostProcessor(LocalValidatorFactoryBean validator) 
	 {
	     MethodValidationPostProcessor processor = new MethodValidationPostProcessor();
	     processor.setValidator(validator);
	     return processor;
	 }	 
}